export const formatPrice = (price) => price.toLocaleString("en-US");
